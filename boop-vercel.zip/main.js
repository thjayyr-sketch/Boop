const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const fmt = n => '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

// sticky nav border
const nav = $('.nav');
addEventListener('scroll', () => nav.classList.toggle('scrolled', scrollY > 10), { passive: true });

// platform detection: highlight the right store
const ua = navigator.userAgent || '';
const platform = /android/i.test(ua) ? 'android' : (/iphone|ipad|ipod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)) ? 'ios' : null;
if (platform) {
  $$(`[data-store="${platform}"]`).forEach(a => a.classList.add('match'));
  $('#detected').textContent = platform === 'ios' ? 'Looks like you’re on iPhone — the App Store button is highlighted.' : 'Looks like you’re on Android — the Google Play button is highlighted.';
}

// store buttons -> coming soon modal
const modal = $('#modal');
const apple = $('[data-store="ios"] svg').outerHTML, play = $('[data-store="android"] svg').outerHTML;
function openModal(which) {
  $('#modal-ic').innerHTML = which === 'ios' ? apple : play;
  $('#modal-h').textContent = which === 'ios' ? 'Coming to the App Store' : 'Coming to Google Play';
  $('#modal-p').textContent = `Boop for ${which === 'ios' ? 'iPhone' : 'Android'} is in final review. Join the waitlist and we’ll send your download link on launch day.`;
  modal.hidden = false; $('#modal-x').focus();
}
function closeModal() { modal.hidden = true; }
$$('[data-store]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); openModal(a.dataset.store); }));
$('#modal-x').onclick = closeModal;
modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
$('#modal-cta').addEventListener('click', () => { closeModal(); setTimeout(() => $('#email').focus(), 400); });
addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

// waitlist (saved to the artifact's shared db when this viewer can write)
$('#wait').addEventListener('submit', async e => {
  e.preventDefault();
  const v = $('#email').value.trim().toLowerCase(), msg = $('#wait-msg');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { msg.textContent = 'Hmm, that email doesn’t look right.'; return; }
  msg.textContent = 'Saving…';
  try {
    const r = await fetch('/api/waitlist', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: v }) });
    if (!r.ok) throw new Error(r.status);
    msg.textContent = 'You’re on the list. We’ll send your link on launch day.';
    $('#email').value = '';
  } catch (_) {
    msg.textContent = 'Couldn’t save your email right now. Please try again later.';
  }
});

// fee calculator
const calc = $('#calc'), range = $('#calc-r');
function upd(v) {
  v = Math.max(0, +v || 0);
  $('#c-tz').textContent = fmt(v ? Math.min(10, Math.max(.25, v * .01)) : 0);
  $('#c-venmo').textContent = fmt(v ? Math.min(25, Math.max(.25, v * .0175)) : 0);
  $('#c-cash').textContent = fmt(v ? Math.min(75, Math.max(.25, v * .025)) : 0);
}
calc.addEventListener('input', () => { range.value = calc.value; upd(calc.value); });
range.addEventListener('input', () => { calc.value = range.value; upd(range.value); });
upd(calc.value);

// preview mode toggle
$$('[data-preview]').forEach(b => b.addEventListener('click', () => {
  $$('[data-preview]').forEach(x => { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b); });
  $('#preview').src = b.dataset.preview === 'business' ? 'app.html?embed&mode=business' : 'app.html?embed';
}));
