// Boop — interactive prototype (demo data only, no real money moves)
if (new URLSearchParams(location.search).has('embed')) document.body.classList.add('embed');
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const fmt = n => (n < 0 ? '−' : '') + '$' + Math.abs(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmt0 = n => '$' + Math.round(n).toLocaleString('en-US');
const money = s => parseFloat(String(s).replace(/[^0-9.]/g, '')) || 0;
const dev = $('#device');

/* ---------------- pricing (proposed Boop pricing) ---------------- */
const PERSONAL_PLANS = {
  free: { name: 'Free', price: 0, instant: [1, 0.25, 10], crypto: 1.25, perks: ['Free payments to friends', 'Free standard bank transfers', 'Instant cash-out 1% (max $10)', 'Commission-free stocks · 1.25% crypto fee', 'Pots, Split and Tap to pay'] },
  plus: { name: 'Plus', price: 4.99, instant: [0, 0, 0], crypto: 0.5, perks: ['Everything in Free', 'Free instant cash-out, unlimited', 'Crypto fee cut to 0.5%', 'Auto round-ups into investing', 'Metal debit card + priority support'] },
};
const BIZ_PLANS = {
  starter: { name: 'Starter', price: 0, tap: [2.6, .10], card: [2.9, .30], keyed: [3.4, .15], ach: [0.9, 0, 5], instant: 1.5, perks: ['Tap to Pay 2.6% + 10¢', 'Online & links 2.9% + 30¢', 'Keyed cards 3.4% + 15¢', 'ACH 0.9% (max $5)', 'Free next-day payouts · instant 1.5%', '5 invoices / month'] },
  pro: { name: 'Pro', price: 29, tap: [2.4, .10], card: [2.7, .30], keyed: [3.2, .15], ach: [0.5, 0, 3], instant: 0, perks: ['Tap to Pay 2.4% + 10¢', 'Online & links 2.7% + 30¢', 'Keyed cards 3.2% + 15¢', 'ACH 0.5% (max $3)', 'Free instant payouts', 'Unlimited invoices + recurring billing', 'Team logins, custom branding, reports'] },
};
const state = {
  mode: 'personal', pplan: 'free', bplan: 'starter',
  balance: 248.50,
  pots: [
    { e: '🏝️', name: 'Cabo trip', have: 1840, goal: 3000, c: '#FFE07A' },
    { e: '🏠', name: 'Rent — Apt 4B', have: 2100, goal: 2400, c: '#CDEFE0' },
    { e: '🎂', name: "Ari's b-day gift", have: 86, goal: 150, c: '#FFD3E2' },
    { e: '🎮', name: 'Game night', have: 24, goal: 60, c: '#E2DBFF' },
  ],
  feed: [
    { from: 'maya', to: 'me', amt: 18, note: 'tacos 🌮 you saved my life', mine: true, plus: true, t: '2m', r: { '🔥': 2, '😂': 1 } },
    { from: 'dev', to: 'luis', note: 'gas money for the road trip ⛽', t: '14m', r: { '🚗': 3 } },
    { from: 'me', to: 'ari', amt: 12.5, note: 'boba run 🧋', mine: true, t: '1h', r: { '💖': 1 } },
    { from: 'zoe', to: 'sam', note: 'concert tix!!! 🎤', t: '3h', r: { '🎉': 4 } },
    { from: 'luis', to: 'me', amt: 40, note: 'utilities split', mine: true, plus: true, t: 'Yesterday', r: {} },
  ],
  assets: [
    { s: 'AAPL', n: 'Apple', k: 'stock', p: 231.40, c: '#1B1035', o: 229.10 },
    { s: 'NVDA', n: 'NVIDIA', k: 'stock', p: 184.20, c: '#0E9F6E', o: 180.75 },
    { s: 'TSLA', n: 'Tesla', k: 'stock', p: 251.30, c: '#E5484D', o: 255.90 },
    { s: 'AMZN', n: 'Amazon', k: 'stock', p: 216.80, c: '#FF8A3D', o: 215.20 },
    { s: 'VOO', n: 'Vanguard S&P 500 ETF', k: 'stock', p: 552.60, c: '#6B4BFF', o: 549.90 },
    { s: 'BTC', n: 'Bitcoin', k: 'crypto', p: 104250, c: '#F7931A', o: 102900 },
    { s: 'ETH', n: 'Ethereum', k: 'crypto', p: 3820, c: '#627EEA', o: 3755 },
    { s: 'SOL', n: 'Solana', k: 'crypto', p: 178.40, c: '#9945FF', o: 181.10 },
    { s: 'USDC', n: 'USD Coin', k: 'crypto', p: 1.00, c: '#2775CA', o: 1.00 },
  ],
  holdings: { AAPL: 1.82, NVDA: 3.1, VOO: 0.9, BTC: 0.0042, ETH: 0.12 },
  biz: {
    avail: 1284.60, pending: 362.40,
    week: [640, 910, 455, 1220, 780, 1490, 0],
    payments: [
      { who: 'Alex Rivera', what: 'Full interior detail', m: 'keyed', amt: 180, t: '10:42 AM', st: 'ok' },
      { who: 'Rivera Landscaping LLC', what: 'Fleet wash — 4 trucks', m: 'ach', amt: 640, t: '9:15 AM', st: 'pend' },
      { who: 'Walk-in customer', what: 'Express wash', m: 'tap', amt: 45, t: '8:30 AM', st: 'ok' },
      { who: 'Priya Shah', what: 'Ceramic coating deposit', m: 'link', amt: 250, t: 'Yesterday', st: 'ok' },
      { who: 'Marcus Lee', what: 'Headlight restoration', m: 'tap', amt: 85, t: 'Yesterday', st: 'ok' },
    ],
    invoices: [
      { no: 1042, cust: 'Rivera Landscaping LLC', amt: 1280, st: 'due', due: 'Overdue 3 days' },
      { no: 1043, cust: 'Delta Property Mgmt', amt: 2150, st: 'pend', due: 'Due Oct 29' },
      { no: 1041, cust: 'Priya Shah', amt: 499, st: 'ok', due: 'Paid Oct 18' },
    ],
    customers: [
      { n: 'Alex Rivera', e: 'Visa ••4242 on file', c: '#FF8A3D' },
      { n: 'Rivera Landscaping LLC', e: 'Chase checking ••6789', c: '#0E9F6E' },
      { n: 'Delta Property Mgmt', e: 'Invoices · Net 30', c: '#6B4BFF' },
      { n: 'Priya Shah', e: 'Mastercard ••4444 on file', c: '#FF3D7F' },
    ],
  },
};
const people = [
  { id: 'maya', name: 'Maya', c: '#FF8A3D' }, { id: 'dev', name: 'Dev', c: '#2FB8D6' }, { id: 'luis', name: 'Luis', c: '#6B4BFF' },
  { id: 'ari', name: 'Ari', c: '#2FD69A' }, { id: 'sam', name: 'Sam', c: '#FF3D7F' }, { id: 'zoe', name: 'Zoe', c: '#E0A800' },
];
const P = id => people.find(p => p.id === id);
const A = s => state.assets.find(a => a.s === s);
const av = (p, size) => `<span class="avatar" style="background:${p.c}${size ? `;width:${size}px;height:${size}px;font-size:${size * .4}px` : ''}">${p.name[0]}</span>`;
const feeOf = (rate, amt) => { if (!rate) return 0; const [pct, fix, cap] = rate; let f = amt * pct / 100 + (fix || 0); if (cap) f = Math.min(cap, f); return Math.round(f * 100) / 100; };

/* ---------------- mode + tabs ---------------- */
const PTABS = ['home', 'invest', 'activity', 'me'], BTABS = ['dash', 'payments', 'invoices', 'more'];
function setMode(m) {
  state.mode = m; dev.classList.toggle('biz', m === 'business');
  $$('.modesw button').forEach(b => b.classList.toggle('on', b.dataset.mode === m));
  $('#tb-personal').hidden = m !== 'personal'; $('#tb-business').hidden = m !== 'business';
  closeSheets(); tab(m === 'personal' ? 'home' : 'dash');
}
$$('.modesw button').forEach(b => b.onclick = () => setMode(b.dataset.mode));
function tab(name) {
  $$('.screen').forEach(s => s.classList.toggle('active', s.id === 's-' + name));
  $$('.tab[data-tab]').forEach(t => t.classList.toggle('on', t.dataset.tab === name));
  $$('.screen.active').forEach(s => s.scrollTop = 0);
}
document.addEventListener('click', e => {
  const t = e.target.closest('[data-tab]'); if (t) { e.preventDefault(); tab(t.dataset.tab); }
  const ts = e.target.closest('[data-toast]'); if (ts) toast(ts.dataset.toast);
});

/* ---------------- sheets ---------------- */
function openSheet(id) { const s = $('#sh-' + id); s.classList.add('open'); s.setAttribute('aria-hidden', 'false'); s.scrollTop = 0; }
function closeSheets() { $$('.sheet').forEach(s => { s.classList.remove('open'); s.setAttribute('aria-hidden', 'true'); }); tapReset(); }
document.addEventListener('click', e => {
  const o = e.target.closest('[data-open]');
  if (o) {
    e.preventDefault(); const id = o.dataset.open;
    if (id === 'send') { setSendMode(o.dataset.sendmode || 'send'); resetSend(); }
    if (id === 'tap') startTap();
    if (id === 'split') renderSplit();
    if (id === 'charge') openCharge(o.dataset.method || 'keyed');
    if (id === 'invoice') openInvoice();
    if (id === 'payout') openPayout();
    if (id === 'plan') renderPlans();
    openSheet(id);
  }
  if (e.target.closest('[data-close]')) closeSheets();
});

/* ---------------- personal: home ---------------- */
function animateBal(to) {
  const el = $('#bal'); const from = parseFloat(el.dataset.v || 0); const t0 = performance.now();
  const step = t => { const k = Math.min(1, (t - t0) / 650); const v = from + (to - from) * (1 - Math.pow(1 - k, 3)); el.textContent = fmt(v); if (k < 1) requestAnimationFrame(step); else el.dataset.v = to; };
  requestAnimationFrame(step);
}
function renderHome() {
  animateBal(state.balance);
  $('#friends').innerHTML = people.map(p => `<button class="friend" data-quick="${p.id}">${av(p)}${p.name}</button>`).join('');
  $('#pots').innerHTML = state.pots.map(p => { const pct = Math.round(p.have / p.goal * 100); return `<div class="pot" style="background:${p.c}"><div class="em">${p.e}</div><div><b>${p.name}</b><span>${fmt0(p.have)} of ${fmt0(p.goal)}</span><div class="bar"><i style="width:${pct}%"></i></div></div></div>`; }).join('');
  $('#upsell').hidden = state.pplan === 'plus';
  $('#cashout').textContent = state.pplan === 'plus' ? '⚡ Cash out · free' : '⚡ Instant cash-out';
  $('#p-plan-name').textContent = PERSONAL_PLANS[state.pplan].name + (state.pplan === 'plus' ? ' · $4.99/mo' : '');
  renderFeed();
}
function feedHTML(f, i) {
  const a = f.from === 'me' ? { name: 'You', c: '#6B4BFF' } : P(f.from); const b = f.to === 'me' ? { name: 'you' } : P(f.to);
  const m = f.amt != null ? `<div class="money ${f.plus ? 'plus' : ''}">${f.plus ? '+' : '−'}${fmt(f.amt)}</div>` : '';
  const rs = Object.entries(f.r).map(([e, n]) => `<button class="react ${f.my && f.my.includes(e) ? 'on' : ''}" data-r="${i}|${e}">${e} ${n}</button>`).join('') + `<button class="react" data-r="${i}|💖">+ 💖</button>`;
  return `<div class="card item">${av(a.name === 'You' ? { name: 'J', c: a.c } : a)}<div class="body"><div class="line1"><b>${a.name}</b> paid <b>${b.name}</b> <span style="color:var(--muted);font-size:12px">· ${f.t}</span></div><div class="note">${f.note}</div><div class="reacts">${rs}</div></div>${m}</div>`;
}
let feedFilter = 'all';
function renderFeed() {
  $('#feed').innerHTML = state.feed.slice(0, 3).map(feedHTML).join('');
  $('#feed-all').innerHTML = state.feed.map((f, i) => ({ f, i })).filter(x => feedFilter === 'all' || x.f.mine).map(x => feedHTML(x.f, x.i)).join('');
}
document.addEventListener('click', e => {
  const r = e.target.closest('[data-r]'); if (!r) return;
  const [i, em] = r.dataset.r.split('|'); const f = state.feed[+i]; f.my = f.my || [];
  if (f.my.includes(em)) { f.my = f.my.filter(x => x !== em); f.r[em]--; if (!f.r[em]) delete f.r[em]; } else { f.my.push(em); f.r[em] = (f.r[em] || 0) + 1; }
  renderFeed();
});
$$('[data-feed]').forEach(b => b.onclick = () => { feedFilter = b.dataset.feed; $$('[data-feed]').forEach(x => x.classList.toggle('on', x === b)); renderFeed(); });
$('#newpot').onclick = () => { state.pots.push({ e: '✨', name: 'New pot', have: 0, goal: 500, c: '#FFE3C2' }); renderHome(); toast('Pot created — invite friends to chip in'); };
$('#cashout').onclick = () => {
  const v = state.balance; if (v <= 0) return toast('Nothing to cash out yet');
  const fee = feeOf(PERSONAL_PLANS[state.pplan].instant, v); const fee2 = state.pplan === 'free' ? Math.max(.25, fee) : 0;
  const venmo = Math.min(25, Math.max(.25, v * .0175)); state.balance = 0;
  succeed('Cashed out!', `${fmt(v - fee2)} is on its way to your bank in seconds. Fee: ${fmt(fee2)} (Venmo would charge ${fmt(venmo)}).`);
};

/* ---------------- send / request ---------------- */
let sendMode = 'send', amt = '0', to = null, sticker = null;
const STK = ['🍕', '🧋', '🎉', '🚕', '🏠', '💖'];
$('#stickers').innerHTML = STK.map(s => `<button data-stk="${s}">${s}</button>`).join('');
$$('[data-stk]').forEach(b => b.onclick = () => { sticker = sticker === b.dataset.stk ? null : b.dataset.stk; $$('[data-stk]').forEach(x => x.classList.toggle('on', x.dataset.stk === sticker)); });
$('#to').innerHTML = people.map(p => `<button class="pick" data-to="${p.id}">${av(p)}${p.name}</button>`).join('');
$$('[data-to]').forEach(b => b.onclick = () => { to = b.dataset.to; $$('[data-to]').forEach(x => x.classList.toggle('on', x === b)); validateSend(); });
$('#keypad').innerHTML = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '.', '0', '⌫'].map(k => `<button class="key" data-k="${k}">${k}</button>`).join('');
$$('[data-k]').forEach(b => b.onclick = () => key(b.dataset.k));
$$('[data-sm]').forEach(b => b.onclick = () => setSendMode(b.dataset.sm));
function setSendMode(m) { sendMode = m; $$('[data-sm]').forEach(x => x.classList.toggle('on', x.dataset.sm === m)); $('#send-title').textContent = m === 'send' ? 'Send money' : 'Request money'; validateSend(); }
function resetSend() { amt = '0'; to = null; sticker = null; $('#note').value = ''; $$('[data-to],[data-stk]').forEach(x => x.classList.remove('on')); renderAmt(); }
function key(k) {
  if (k === '⌫') amt = amt.length > 1 ? amt.slice(0, -1) : '0';
  else if (k === '.') { if (!amt.includes('.')) amt += '.'; }
  else { if ((amt.includes('.') && amt.split('.')[1].length >= 2) || amt.replace('.', '').length >= 6) return bump(); amt = amt === '0' ? k : amt + k; }
  renderAmt();
}
function bump() { const a = $('#amt'); a.classList.remove('shake'); void a.offsetWidth; a.classList.add('shake'); }
function renderAmt() { $('#amt').textContent = '$' + amt; const v = parseFloat(amt) || 0; $('#feehint').textContent = sendMode === 'send' && v > state.balance ? 'Covered by your linked debit card — still free' : (v > 0 ? 'Arrives instantly · $0.00 fee' : 'Instant. Free.'); validateSend(); }
function validateSend() { const v = parseFloat(amt) || 0; const b = $('#send-go'); b.disabled = !(v > 0 && to); b.textContent = to ? `${sendMode === 'send' ? 'Pay' : 'Request'} ${P(to).name}${v > 0 ? ' ' + fmt(v) : ''}` : (sendMode === 'send' ? 'Pay' : 'Request'); }
$('#send-go').onclick = () => {
  const v = parseFloat(amt); const p = P(to); const note = ($('#note').value || 'just because') + (sticker ? ' ' + sticker : '');
  if (sendMode === 'send') { state.balance = Math.max(0, state.balance - v); state.feed.unshift({ from: 'me', to: p.id, amt: v, note, mine: true, t: 'now', r: {} }); succeed('Sent!', `${fmt(v)} is already in ${p.name}'s Boop. No fee, no wait.`); }
  else { state.feed.unshift({ from: 'me', to: p.id, note: '📨 requested ' + fmt(v) + ' · ' + note, mine: true, t: 'now', r: {} }); succeed('Requested!', `We nudged ${p.name} for ${fmt(v)}. You'll get a ping when it lands.`); }
};
document.addEventListener('click', e => { const q = e.target.closest('[data-quick]'); if (q) { setSendMode('send'); resetSend(); openSheet('send'); to = q.dataset.quick; $$('[data-to]').forEach(x => x.classList.toggle('on', x.dataset.to === to)); validateSend(); } });

/* ---------------- tap to pay (personal + business) ---------------- */
let tapTimers = [], tapTarget = null, tapBiz = false;
function tapReset() { tapTimers.forEach(clearTimeout); tapTimers = []; ['#found', '#found2'].forEach(s => { $(s).classList.remove('show'); $(s).style.opacity = ''; }); const g = $('#tap-go'); g.disabled = true; tapTarget = null; }
function startTap() {
  tapReset(); tapBiz = state.mode === 'business'; const g = $('#tap-go');
  if (tapBiz) {
    const v = 85; $('#tap-title').textContent = 'Tap to Pay'; $('#tap-h').textContent = 'Charge ' + fmt(v); $('#tap-p').textContent = 'Ask the customer to hold their card or phone near the top of your phone.'; g.textContent = 'Waiting for card…';
    tapTimers.push(setTimeout(() => { $('#tap-h').textContent = 'Card detected 💳'; $('#tap-p').textContent = 'Visa contactless ••1881 · approved'; g.disabled = false; g.textContent = 'Complete ' + fmt(v); }, 2000));
  } else {
    $('#tap-title').textContent = 'Tap to pay'; $('#tap-h').textContent = 'Hold phones close…'; $('#tap-p').textContent = "Tap your phone to a friend's. No usernames, no typos."; g.textContent = 'Searching…';
    tapTimers.push(setTimeout(() => $('#found').classList.add('show'), 1300));
    tapTimers.push(setTimeout(() => { $('#found2').classList.add('show'); $('#tap-h').textContent = '2 friends nearby'; $('#tap-p').textContent = 'Tap a face to send them $20.'; g.textContent = 'Pick someone'; }, 2200));
  }
}
['found', 'found2'].forEach((id, i) => $('#' + id).onclick = () => { if (tapBiz) return; tapTarget = i ? 'dev' : 'maya'; $('#found').style.opacity = i ? '.35' : ''; $('#found2').style.opacity = i ? '' : '.35'; const g = $('#tap-go'); g.disabled = false; g.textContent = `Send ${P(tapTarget).name} $20`; });
$('#tap-go').onclick = () => {
  if (tapBiz) { addPayment({ who: 'Walk-in customer', what: 'Tap to Pay sale', m: 'tap', amt: 85 }); return; }
  if (!tapTarget) return; const p = P(tapTarget); state.balance = Math.max(0, state.balance - 20);
  state.feed.unshift({ from: 'me', to: p.id, amt: 20, note: '👋 tapped in person', mine: true, t: 'now', r: {} });
  succeed('Tapped!', `$20.00 landed in ${p.name}'s Boop the second your phones touched.`);
};

/* ---------------- split ---------------- */
let tip = 0; const splitSel = new Set(['maya', 'dev', 'luis']);
function renderSplit() {
  const total = money($('#total').value) * (1 + tip / 100); const n = splitSel.size + 1; const share = total / n;
  $('#split-list').innerHTML = `<div class="split-row on"><span class="check">✓</span>${av({ name: 'J', c: '#6B4BFF' }, 36)}<span class="nm">You</span><span class="sh">${fmt(share)}</span></div>` +
    people.slice(0, 5).map(p => `<button class="split-row ${splitSel.has(p.id) ? 'on' : ''}" data-sp="${p.id}"><span class="check">${splitSel.has(p.id) ? '✓' : ''}</span>${av(p, 36)}<span class="nm">${p.name}</span><span class="sh">${splitSel.has(p.id) ? fmt(share) : '—'}</span></button>`).join('');
  $$('[data-sp]').forEach(b => b.onclick = () => { const id = b.dataset.sp; splitSel.has(id) ? splitSel.delete(id) : splitSel.add(id); renderSplit(); });
  $('#split-sum').textContent = `${fmt(total)} total · ${n} people · ${fmt(share)} each`;
  const g = $('#split-go'); g.disabled = splitSel.size === 0; g.textContent = splitSel.size ? `Request ${fmt(share)} from ${splitSel.size}` : 'Pick friends';
}
$('#total').addEventListener('input', renderSplit);
$('#total').addEventListener('blur', () => { $('#total').value = fmt(money($('#total').value)); });
$$('#tipseg [data-tip]').forEach(b => b.onclick = () => { tip = +b.dataset.tip; $$('#tipseg [data-tip]').forEach(x => x.classList.toggle('on', x === b)); renderSplit(); });
$('#split-go').onclick = () => {
  const share = money($('#total').value) * (1 + tip / 100) / (splitSel.size + 1); const names = [...splitSel].map(id => P(id).name);
  state.feed.unshift({ from: 'me', to: [...splitSel][0], note: `🧾 split ${fmt(share)} each with ${names.join(', ')}`, mine: true, t: 'now', r: {} });
  succeed('Split!', `${names.join(', ')} each got a request for ${fmt(share)}. We'll auto-remind them.`);
};

/* ---------------- add money ---------------- */
let addV = 50;
$$('#addseg [data-v]').forEach(b => b.onclick = () => { addV = +b.dataset.v; $$('#addseg [data-v]').forEach(x => x.classList.toggle('on', x === b)); $('#add-amt').textContent = '$' + addV; $('#add-go').textContent = 'Add $' + addV; });
$('#add-go').onclick = () => { state.balance += addV; closeSheets(); renderAll(); toast(`+$${addV} added instantly`); };

/* ---------------- invest ---------------- */
const hist = {}; // symbol -> array
function seedHist(a, range) { const n = 40; const vol = { '1D': .004, '1W': .01, '1M': .02, '1Y': .05 }[range] * (a.k === 'crypto' ? 1.8 : 1); let v = a.p; const arr = [v]; for (let i = 1; i < n; i++) { v = v / (1 + (Math.random() - .48) * vol); arr.unshift(v); } return arr; }
let range = '1D';
state.assets.forEach(a => hist[a.s] = seedHist(a, range));
function spark(arr, w = 54, h = 24, color) {
  const mn = Math.min(...arr), mx = Math.max(...arr), d = mx - mn || 1;
  const pts = arr.map((v, i) => `${(i / (arr.length - 1) * w).toFixed(1)},${(h - 2 - (v - mn) / d * (h - 4)).toFixed(1)}`).join(' ');
  const c = color || (arr[arr.length - 1] >= arr[0] ? 'var(--green)' : 'var(--red)');
  return `<polyline points="${pts}" fill="none" stroke="${c}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>`;
}
function bigChart(svg, arr) {
  const w = 300, h = 120, mn = Math.min(...arr), mx = Math.max(...arr), d = mx - mn || 1; const up = arr[arr.length - 1] >= arr[0];
  const pts = arr.map((v, i) => [i / (arr.length - 1) * w, h - 8 - (v - mn) / d * (h - 16)]);
  const line = pts.map(p => p.join(',')).join(' '); const c = up ? '#0E9F6E' : '#E5484D';
  svg.innerHTML = `<defs><linearGradient id="g${svg.id}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${c}" stop-opacity=".25"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></linearGradient></defs><polygon points="0,${h} ${line} ${w},${h}" fill="url(#g${svg.id})"/><polyline points="${line}" fill="none" stroke="${c}" stroke-width="2.5" vector-effect="non-scaling-stroke" stroke-linejoin="round"/>`;
}
const portValue = () => Object.entries(state.holdings).reduce((s, [k, q]) => s + q * A(k).p, 0);
const portOpen = () => Object.entries(state.holdings).reduce((s, [k, q]) => s + q * A(k).o, 0);
function assetRow(a, held) {
  const ch = (a.p - a.o) / a.o * 100; const up = ch >= 0; const q = state.holdings[a.s] || 0;
  const pxs = a.p >= 1000 ? fmt0(a.p) : fmt(a.p);
  return `<button class="asset" data-asset="${a.s}"><span class="logo" style="background:${a.c}">${a.s.slice(0, 4)}</span><span class="nm"><b>${held ? a.s : a.n}</b><span>${held ? (q < 0.01 ? q.toFixed(5) : q.toFixed(3)) + ' ' + (a.k === 'crypto' ? a.s : 'shares') : a.s}</span></span><svg viewBox="0 0 54 24">${spark(hist[a.s].slice(-20))}</svg><span class="px"><b>${held ? fmt(q * a.p) : pxs}</b><span style="color:${up ? 'var(--green)' : 'var(--red)'}">${up ? '+' : ''}${ch.toFixed(2)}%</span></span></button>`;
}
let kind = 'stock';
function renderInvest() {
  const v = portValue(), o = portOpen(), d = v - o, pct = o ? d / o * 100 : 0;
  $('#port-val').textContent = fmt(v);
  const pd = $('#port-delta'); pd.textContent = `${d >= 0 ? '+' : '−'}${fmt(Math.abs(d))} (${pct.toFixed(2)}%) ${range === '1D' ? 'today' : 'past ' + range}`; pd.className = 'delta ' + (d >= 0 ? 'up' : 'down');
  $('#mini-port').textContent = fmt(v); const md = $('#mini-delta'); md.textContent = `${pct >= 0 ? '▲' : '▼'} ${Math.abs(pct).toFixed(2)}% today`; md.className = 'delta ' + (pct >= 0 ? 'up' : 'down');
  // portfolio history = weighted sum
  const n = 40, ph = []; for (let i = 0; i < n; i++) ph.push(Object.entries(state.holdings).reduce((s, [k, q]) => s + q * hist[k][i], 0));
  bigChart($('#port-chart'), ph);
  const held = Object.keys(state.holdings).filter(k => state.holdings[k] > 1e-7);
  $('#holdings').innerHTML = held.length ? held.map(k => assetRow(A(k), true)).join('') : '<div class="empty">No investments yet — start with as little as $1.</div>';
  $('#market').innerHTML = state.assets.filter(a => a.k === kind).map(a => assetRow(a, false)).join('');
  $('#cash-avail').textContent = fmt(state.balance) + ' cash to invest';
}
$$('#asset-kind [data-k]').forEach(b => b.onclick = () => { kind = b.dataset.k; $$('#asset-kind [data-k]').forEach(x => x.classList.toggle('on', x === b)); renderInvest(); });
$$('#range [data-r]').forEach(b => b.onclick = () => { range = b.dataset.r; $$('#range [data-r]').forEach(x => x.classList.toggle('on', x === b)); state.assets.forEach(a => hist[a.s] = seedHist(a, range)); renderInvest(); });
// live ticking demo prices
setInterval(() => {
  state.assets.forEach(a => { if (a.s === 'USDC') return; const vol = a.k === 'crypto' ? .0018 : .0008; a.p = Math.max(.01, a.p * (1 + (Math.random() - .5) * vol)); hist[a.s].push(a.p); hist[a.s].shift(); });
  if ($('#s-invest').classList.contains('active') || $('#s-home').classList.contains('active')) renderInvest();
  if ($('#sh-trade').classList.contains('open')) renderTrade(false);
}, 2500);
// trade
let tradeSym = null, side = 'buy';
document.addEventListener('click', e => { const a = e.target.closest('[data-asset]'); if (a) { tradeSym = a.dataset.asset; side = 'buy'; $$('#side [data-side]').forEach(x => x.classList.toggle('on', x.dataset.side === 'buy')); $('#trade-amt').value = '$50'; renderTrade(true); openSheet('trade'); } });
$$('#side [data-side]').forEach(b => b.onclick = () => { side = b.dataset.side; $$('#side [data-side]').forEach(x => x.classList.toggle('on', x === b)); renderTrade(true); });
$$('#trade-quick [data-q]').forEach(b => b.onclick = () => { const a = A(tradeSym); const max = side === 'buy' ? state.balance : (state.holdings[tradeSym] || 0) * a.p; $('#trade-amt').value = fmt(b.dataset.q === 'max' ? Math.floor(max * 100) / 100 : +b.dataset.q); renderTrade(true); });
$('#trade-amt').addEventListener('input', () => renderTrade(true));
$('#trade-amt').addEventListener('blur', () => { $('#trade-amt').value = fmt(money($('#trade-amt').value)); });
function tradeFee(a, v) { return a.k === 'crypto' && a.s !== 'USDC' ? Math.round(v * PERSONAL_PLANS[state.pplan].crypto) / 100 : 0; }
function renderTrade(redrawChart) {
  const a = A(tradeSym); if (!a) return; const v = money($('#trade-amt').value); const ch = (a.p - a.o) / a.o * 100;
  $('#trade-title').textContent = (side === 'buy' ? 'Buy ' : 'Sell ') + a.s;
  $('#trade-head').innerHTML = `<span class="logo" style="background:${a.c}">${a.s.slice(0, 4)}</span><div><b>${a.n}</b><span>${a.p >= 1000 ? fmt0(a.p) : fmt(a.p)} · <span style="color:${ch >= 0 ? 'var(--green)' : 'var(--red)'};font-weight:700">${ch >= 0 ? '+' : ''}${ch.toFixed(2)}%</span></span></div>`;
  if (redrawChart || true) bigChart($('#trade-chart'), hist[a.s]);
  const fee = tradeFee(a, v); const qty = (side === 'buy' ? v - fee : v) / a.p; const own = state.holdings[a.s] || 0;
  const feeLbl = a.k === 'crypto' && a.s !== 'USDC' ? `Crypto fee (${PERSONAL_PLANS[state.pplan].crypto}%)` : 'Commission';
  $('#trade-bd').innerHTML = `<div><span>Est. ${a.k === 'crypto' ? a.s : 'shares'}</span><span>${qty > 0 ? qty.toFixed(a.k === 'crypto' ? 6 : 4) : '0'}</span></div><div><span>${feeLbl}</span><span>${fmt(fee)}</span></div><div><span>${side === 'buy' ? 'Cash available' : 'You own'}</span><span>${side === 'buy' ? fmt(state.balance) : fmt(own * a.p)}</span></div><div><span>${side === 'buy' ? 'Total cost' : 'You receive'}</span><span>${fmt(side === 'buy' ? v : v - fee)}</span></div>`;
  const g = $('#trade-go'); const ok = v >= 1 && (side === 'buy' ? v <= state.balance + 1e-9 : v <= own * a.p + 0.005);
  g.disabled = !ok; g.textContent = ok ? `${side === 'buy' ? 'Buy' : 'Sell'} ${fmt(v)} of ${a.s}` : (v < 1 ? 'Minimum $1' : side === 'buy' ? 'Not enough cash — add money' : `You own ${fmt(own * a.p)}`);
}
$('#trade-go').onclick = () => {
  const a = A(tradeSym); const v = money($('#trade-amt').value); const fee = tradeFee(a, v);
  if (side === 'buy') { state.balance -= v; state.holdings[a.s] = (state.holdings[a.s] || 0) + (v - fee) / a.p; succeed('Order filled!', `You bought ${fmt(v - fee)} of ${a.n}${fee ? ` (${fmt(fee)} fee)` : ' — commission-free'}.`); }
  else { const q = Math.min(state.holdings[a.s], v / a.p); state.holdings[a.s] -= q; if (state.holdings[a.s] * a.p < 0.01) delete state.holdings[a.s]; state.balance += v - fee; succeed('Sold!', `${fmt(v - fee)} from ${a.n} is back in your Boop balance.`); }
};

/* ---------------- business ---------------- */
const MICON = { keyed: '💳', card: '💳', link: '🔗', ach: '🏦', tap: '📲', invoice: '🧾' };
const MLBL = { keyed: 'Keyed card', card: 'Online card', link: 'Payment link', ach: 'ACH debit', tap: 'Tap to Pay', invoice: 'Invoice' };
const rateFor = m => { const pl = BIZ_PLANS[state.bplan]; return m === 'keyed' ? pl.keyed : m === 'ach' ? pl.ach : m === 'tap' ? pl.tap : pl.card; };
const rateTxt = r => r.length === 3 && r[2] ? `${r[0]}% (max $${r[2]})` : `${r[0]}% + ${Math.round(r[1] * 100)}¢`;
function payRow(p, i) {
  const st = { ok: ['ok', 'Paid'], pend: ['pend', p.m === 'ach' ? 'Clearing (1–3 days)' : 'Pending'], ref: ['ref', 'Refunded'] }[p.st];
  return `<button class="pay" data-pay="${i}"><span class="pi">${MICON[p.m]}</span><span class="nm"><b>${p.who}</b><span>${p.what} · ${p.t}</span></span><span class="am"><b>${p.st === 'ref' ? '<s>' + fmt(p.amt) + '</s>' : fmt(p.amt)}</b><span class="badge ${st[0]}">${st[1]}</span></span></button>`;
}
let payFilter = 'all';
function renderBiz() {
  const b = state.biz;
  $('#b-avail').textContent = fmt(b.avail); $('#b-pending').textContent = fmt(b.pending) + ' pending (ACH clearing)';
  const today = b.payments.filter(p => /AM|PM|now/.test(p.t) && p.st !== 'ref');
  const gross = today.reduce((s, p) => s + p.amt, 0); b.week[6] = gross;
  $('#st-gross').textContent = fmt0(gross); $('#st-count').textContent = today.length; $('#st-avg').textContent = fmt0(today.length ? gross / today.length : 0);
  const mx = Math.max(...b.week, 1); const days = ['Fri', 'Sat', 'Sun', 'Mon', 'Tue', 'Wed', 'Today'];
  $('#bars').innerHTML = b.week.map((v, i) => `<div><i style="height:${Math.max(4, v / mx * 70)}px"></i><span>${days[i]}</span></div>`).join('');
  $('#wk-total').textContent = fmt0(b.week.reduce((s, v) => s + v, 0)) + ' gross';
  $('#recent').innerHTML = b.payments.slice(0, 4).map(payRow).join('');
  const list = b.payments.map((p, i) => ({ p, i })).filter(x => payFilter === 'all' || (payFilter === 'card' ? ['keyed', 'card', 'link'].includes(x.p.m) : x.p.m === payFilter));
  $('#paylist').innerHTML = list.length ? list.map(x => payRow(x.p, x.i)).join('') : '<div class="empty">No payments of this type yet.</div>';
  // invoices
  const inv = b.invoices; const sum = st => inv.filter(x => x.st === st).reduce((s, x) => s + x.amt, 0);
  $('#inv-out').textContent = fmt0(sum('pend') + sum('due')); $('#inv-over').textContent = fmt0(sum('due')); $('#inv-paid').textContent = fmt0(sum('ok'));
  $('#invlist').innerHTML = inv.map((x, i) => `<button class="pay" data-inv="${i}"><span class="pi">🧾</span><span class="nm"><b>#${x.no} · ${x.cust}</b><span>${x.due}</span></span><span class="am"><b>${fmt(x.amt)}</b><span class="badge ${x.st}">${{ ok: 'Paid', pend: 'Sent', due: 'Overdue' }[x.st]}</span></span></button>`).join('');
  $('#custlist').innerHTML = b.customers.map(c => `<div class="pay"><span class="avatar" style="background:${c.c};width:38px;height:38px">${c.n[0]}</span><span class="nm"><b>${c.n}</b><span>${c.e}</span></span><button class="badge ref" data-charge-cust="${c.n}" style="font-size:12px;padding:6px 10px">Charge</button></div>`).join('');
  $('#cust-count').textContent = b.customers.length + ' saved';
  $('#b-plan-name').textContent = BIZ_PLANS[state.bplan].name + (state.bplan === 'pro' ? ' · $29/mo' : ' · Free');
  $('#recurring .pro').hidden = state.bplan === 'pro';
}
$$('#payfilter [data-f]').forEach(b => b.onclick = () => { payFilter = b.dataset.f; $$('#payfilter [data-f]').forEach(x => x.classList.toggle('on', x === b)); renderBiz(); });
$('#recurring').onclick = () => { if (state.bplan !== 'pro') { renderPlans(); openSheet('plan'); toast('Recurring billing is a Pro feature'); } else toast('Recurring plan created: $120/mo · Delta Property Mgmt'); };
document.addEventListener('click', e => {
  const c = e.target.closest('[data-charge-cust]'); if (c) { e.stopPropagation(); openCharge('keyed'); $('#cc-name').value = c.dataset.chargeCust; openSheet('charge'); }
  const p = e.target.closest('[data-pay]'); if (p) openDetail(+p.dataset.pay);
  const iv = e.target.closest('[data-inv]'); if (iv) { const x = state.biz.invoices[+iv.dataset.inv]; if (x.st === 'ok') return toast(`Invoice #${x.no} is paid`); toast(`Reminder sent to ${x.cust}`); }
});
function openDetail(i) {
  const p = state.biz.payments[i]; const fee = feeOf(rateFor(p.m), p.amt);
  $('#detail').innerHTML = `<div class="amount" style="font-size:48px">${fmt(p.amt)}</div><div class="feehint">${p.who} · ${MLBL[p.m]}</div><div class="breakdown" style="margin-top:16px"><div><span>Description</span><span>${p.what}</span></div><div><span>Time</span><span>${p.t}</span></div><div><span>Processing fee</span><span>−${fmt(fee)}</span></div><div><span>Net</span><span>${fmt(p.amt - fee)}</span></div></div>
  <button class="cta ghost" data-toast="Receipt texted to customer">Send receipt</button>${p.st !== 'ref' ? `<button class="cta ink" id="refund">Refund ${fmt(p.amt)}</button>` : '<p class="hint" style="margin-top:12px">This payment was refunded.</p>'}`;
  openSheet('detail');
  const r = $('#refund'); if (r) r.onclick = () => { p.st = 'ref'; if (p.m !== 'ach') state.biz.avail = Math.max(0, state.biz.avail - (p.amt - fee)); closeSheets(); renderBiz(); toast('Refund issued — customer sees it in 5–10 days'); };
}
function addPayment(p) {
  const fee = feeOf(rateFor(p.m), p.amt); const ach = p.m === 'ach';
  state.biz.payments.unshift({ ...p, t: 'now', st: ach ? 'pend' : 'ok' });
  if (ach) state.biz.pending += p.amt - fee; else state.biz.avail += p.amt - fee;
  succeed(ach ? 'Debit started!' : 'Payment approved!', `${fmt(p.amt)} from ${p.who}. Fee ${fmt(fee)} · you net ${fmt(p.amt - fee)}${ach ? ' once the ACH clears (1–3 business days).' : ', available now.'}`);
}
// virtual terminal
let chMethod = 'keyed', achType = 'checking';
function openCharge(m) { setMethod(m); $('#link-url').textContent = 'boop.me/pay/jays-detailing/' + Math.random().toString(36).slice(2, 8); qr($('#link-qr'), $('#link-url').textContent); updCharge(); }
function setMethod(m) { chMethod = m; $$('#ch-method [data-m]').forEach(x => x.classList.toggle('on', x.dataset.m === m)); $('#f-keyed').hidden = m !== 'keyed'; $('#f-ach').hidden = m !== 'ach'; $('#f-link').hidden = m !== 'link'; updCharge(); }
$$('#ch-method [data-m]').forEach(b => b.onclick = () => setMethod(b.dataset.m));
$$('#ach-type [data-t]').forEach(b => b.onclick = () => { achType = b.dataset.t; $$('#ach-type [data-t]').forEach(x => x.classList.toggle('on', x === b)); });
const luhn = n => { let s = 0, alt = false; for (let i = n.length - 1; i >= 0; i--) { let d = +n[i]; if (alt) { d *= 2; if (d > 9) d -= 9; } s += d; alt = !alt; } return n.length >= 13 && s % 10 === 0; };
const brand = n => /^4/.test(n) ? 'VISA' : /^(5[1-5]|2[2-7])/.test(n) ? 'MASTERCARD' : /^3[47]/.test(n) ? 'AMEX' : /^6(011|5)/.test(n) ? 'DISCOVER' : '';
const aba = r => { if (!/^\d{9}$/.test(r)) return false; const d = r.split('').map(Number); return (3 * (d[0] + d[3] + d[6]) + 7 * (d[1] + d[4] + d[7]) + (d[2] + d[5] + d[8])) % 10 === 0; };
$('#cc-num').addEventListener('input', e => { const raw = e.target.value.replace(/\D/g, '').slice(0, 19); const b = brand(raw); e.target.value = b === 'AMEX' ? raw.replace(/^(\d{0,4})(\d{0,6})(\d{0,5}).*/, (m, a, c, d) => [a, c, d].filter(Boolean).join(' ')) : raw.replace(/(\d{4})(?=\d)/g, '$1 '); const bb = $('#cc-brand'); bb.hidden = !b; bb.textContent = b; updCharge(); });
$('#cc-exp').addEventListener('input', e => { let v = e.target.value.replace(/\D/g, '').slice(0, 4); if (v.length >= 3) v = v.slice(0, 2) + '/' + v.slice(2); e.target.value = v; updCharge(); });
['#cc-cvc', '#cc-zip', '#ach-rt', '#ach-acct', '#ach-acct2'].forEach(s => $(s).addEventListener('input', e => { e.target.value = e.target.value.replace(/\D/g, ''); updCharge(); }));
['#cc-name', '#ach-name', '#ch-amt', '#ch-desc'].forEach(s => $(s).addEventListener('input', updCharge));
$('#ach-auth').addEventListener('change', updCharge);
$('#ch-amt').addEventListener('blur', () => { $('#ch-amt').value = fmt(money($('#ch-amt').value)); });
function expOk(v) { const m = v.match(/^(\d{2})\/(\d{2})$/); if (!m) return false; const mo = +m[1], yr = 2000 + +m[2]; if (mo < 1 || mo > 12) return false; const now = new Date(); return yr > now.getFullYear() || (yr === now.getFullYear() && mo >= now.getMonth() + 1); }
function mark(el, ok, errEl, msg) { el.classList.toggle('bad', ok === false); el.classList.toggle('good', ok === true); if (errEl) errEl.textContent = ok === false ? msg : ''; }
function updCharge() {
  const v = money($('#ch-amt').value); const r = rateFor(chMethod); const fee = v ? feeOf(r, v) : 0;
  $('#ch-bd').innerHTML = `<div><span>${MLBL[chMethod]} rate (${BIZ_PLANS[state.bplan].name})</span><span>${rateTxt(r)}</span></div><div><span>Processing fee</span><span>−${fmt(fee)}</span></div><div><span>You receive</span><span>${fmt(Math.max(0, v - fee))}</span></div>`;
  let ok = v >= 1;
  if (chMethod === 'keyed') {
    const n = $('#cc-num').value.replace(/\s/g, ''), ex = $('#cc-exp').value, cvc = $('#cc-cvc').value, zip = $('#cc-zip').value, nm = $('#cc-name').value.trim();
    const nOk = n.length ? (n.length >= 13 && luhn(n)) : null; mark($('#cc-num'), n.length >= 13 ? nOk : (n.length ? null : null), $('#cc-num-err'), 'Card number is not valid');
    if (n.length >= 13 && !nOk) mark($('#cc-num'), false, $('#cc-num-err'), 'Card number is not valid');
    const eOk = ex.length === 5 ? expOk(ex) : null; mark($('#cc-exp'), eOk, $('#cc-exp-err'), 'Expired or invalid');
    const needCvc = brand(n) === 'AMEX' ? 4 : 3;
    ok = ok && nOk && eOk && cvc.length === needCvc && zip.length === 5 && nm.length > 1;
    $('#ch-go').textContent = ok ? `Charge ${fmt(v)}` : 'Enter card details';
  } else if (chMethod === 'ach') {
    const rt = $('#ach-rt').value, a1 = $('#ach-acct').value, a2 = $('#ach-acct2').value;
    const rOk = rt.length === 9 ? aba(rt) : null; mark($('#ach-rt'), rOk, $('#ach-rt-err'), 'Routing number failed the bank checksum');
    const aOk = a2.length ? a1 === a2 && a1.length >= 4 : null; mark($('#ach-acct2'), aOk, $('#ach-acct-err'), "Account numbers don't match");
    ok = ok && rOk && aOk && $('#ach-name').value.trim().length > 1 && $('#ach-auth').checked;
    $('#ch-go').textContent = ok ? `Debit ${fmt(v)} by ACH` : ($('#ach-auth').checked || !rOk ? 'Enter bank details' : 'Confirm customer authorization');
  } else { $('#ch-go').textContent = v >= 1 ? 'Copy & text link to customer' : 'Enter an amount'; }
  $('#ch-go').disabled = !ok;
}
$('#ch-go').onclick = () => {
  const v = money($('#ch-amt').value), desc = $('#ch-desc').value || 'Sale', g = $('#ch-go');
  if (chMethod === 'link') { navigator.clipboard?.writeText('https://' + $('#link-url').textContent).catch(() => {}); closeSheets(); toast('Payment link copied — paid links show up in Payments'); return; }
  g.disabled = true; g.innerHTML = '<span class="spin"></span>Processing…';
  setTimeout(() => {
    const who = chMethod === 'keyed' ? $('#cc-name').value.trim() : $('#ach-name').value.trim();
    if (chMethod === 'keyed' && $('#cc-save').checked && !state.biz.customers.some(c => c.n === who)) { const n = $('#cc-num').value.replace(/\s/g, ''); state.biz.customers.unshift({ n: who, e: `${brand(n) || 'Card'} ••${n.slice(-4)} on file`, c: '#2FB8D6' }); }
    if (chMethod === 'ach' && !state.biz.customers.some(c => c.n === who)) state.biz.customers.unshift({ n: who, e: `${achType[0].toUpperCase() + achType.slice(1)} ••${$('#ach-acct').value.slice(-4)}`, c: '#0E9F6E' });
    addPayment({ who, what: desc, m: chMethod, amt: v });
    ['#cc-num', '#cc-exp', '#cc-cvc', '#cc-zip', '#cc-name', '#ach-name', '#ach-rt', '#ach-acct', '#ach-acct2'].forEach(s => { $(s).value = ''; $(s).classList.remove('good', 'bad'); }); $('#ach-auth').checked = false; $('#cc-brand').hidden = true;
  }, 1200);
};
// invoices
let invDue = 7, invLines = [];
function openInvoice() {
  const cs = state.biz.customers; $('#inv-cust').innerHTML = cs.map(c => `<option>${c.n}</option>`).join('');
  invLines = [{ d: 'Monthly fleet wash', a: 480 }, { d: 'Interior shampoo add-on', a: 120 }]; renderLines();
}
function renderLines() {
  $('#inv-lines').innerHTML = invLines.map((l, i) => `<div class="line-item"><input class="inp" data-ld="${i}" value="${l.d}" placeholder="Item" aria-label="Item description"><input class="inp" data-la="${i}" value="${l.a ? fmt(l.a) : ''}" inputmode="decimal" placeholder="$0.00" aria-label="Item amount"><button data-lx="${i}" aria-label="Remove">✕</button></div>`).join('');
  $$('[data-ld]').forEach(x => x.oninput = () => { invLines[+x.dataset.ld].d = x.value; updInv(); });
  $$('[data-la]').forEach(x => { x.oninput = () => { invLines[+x.dataset.la].a = money(x.value); updInv(); }; x.onblur = () => { x.value = fmt(money(x.value)); }; });
  $$('[data-lx]').forEach(x => x.onclick = () => { invLines.splice(+x.dataset.lx, 1); renderLines(); });
  updInv();
}
$('#inv-add').onclick = () => { invLines.push({ d: '', a: 0 }); renderLines(); };
$$('#inv-due [data-d]').forEach(b => b.onclick = () => { invDue = +b.dataset.d; $$('#inv-due [data-d]').forEach(x => x.classList.toggle('on', x === b)); });
$('#inv-ach').addEventListener('change', updInv);
function updInv() {
  const tot = invLines.reduce((s, l) => s + (l.a || 0), 0); const pl = BIZ_PLANS[state.bplan];
  const used = state.biz.invoices.length; const limit = state.bplan === 'starter' && used >= 5;
  $('#inv-bd').innerHTML = `<div><span>Fee if paid by card</span><span>${fmt(tot ? feeOf(pl.card, tot) : 0)}</span></div>${$('#inv-ach').checked ? `<div><span>Fee if paid by ACH</span><span>${fmt(tot ? feeOf(pl.ach, tot) : 0)}</span></div>` : ''}<div><span>Invoice total</span><span>${fmt(tot)}</span></div>`;
  const g = $('#inv-go'); g.disabled = !(tot > 0) || limit; g.textContent = limit ? 'Starter limit reached — upgrade to Pro' : `Send invoice · ${fmt(tot)}`;
}
$('#inv-go').onclick = () => {
  const tot = invLines.reduce((s, l) => s + (l.a || 0), 0); const cust = $('#inv-cust').value; const no = Math.max(...state.biz.invoices.map(x => x.no)) + 1;
  const d = new Date(Date.now() + invDue * 864e5); const dl = invDue ? 'Due ' + d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : 'Due on receipt';
  state.biz.invoices.unshift({ no, cust, amt: tot, st: 'pend', due: dl });
  succeed('Invoice sent!', `Invoice #${no} for ${fmt(tot)} is on its way to ${cust}. ${$('#inv-remind').checked ? "We'll handle the reminders." : ''}`);
};
// payouts
let poKind = 'standard';
function openPayout() {
  const v = state.biz.avail; $('#po-amt').textContent = fmt(v); const pl = BIZ_PLANS[state.bplan]; const ifee = Math.round(v * pl.instant) / 100;
  $('#po-opts').innerHTML = `<button class="plan ${poKind === 'standard' ? 'on' : ''}" data-po="standard"><div class="top"><b style="font-size:18px">Next business day</b><span>Free</span></div></button><button class="plan ${poKind === 'instant' ? 'on' : ''}" data-po="instant"><div class="top"><b style="font-size:18px">Instant · in minutes</b><span>${pl.instant ? fmt(ifee) + ' (' + pl.instant + '%)' : 'Free on Pro'}</span></div></button>`;
  $$('[data-po]').forEach(b => b.onclick = () => { poKind = b.dataset.po; openPayout(); });
  const g = $('#po-go'); g.disabled = v <= 0; g.textContent = v > 0 ? `Pay out ${fmt(poKind === 'instant' ? v - ifee : v)}` : 'Nothing to pay out';
}
$('#po-go').onclick = () => { const v = state.biz.avail; const pl = BIZ_PLANS[state.bplan]; const fee = poKind === 'instant' ? Math.round(v * pl.instant) / 100 : 0; state.biz.avail = 0; succeed('Payout sent!', `${fmt(v - fee)} is headed to Chase ••7710 ${poKind === 'instant' ? 'and should land in minutes' : 'by the next business day'}.`); };
// plans
function renderPlans() {
  const biz = state.mode === 'business'; const plans = biz ? BIZ_PLANS : PERSONAL_PLANS; const cur = biz ? state.bplan : state.pplan;
  $('#plan-title').textContent = biz ? 'Business plans' : 'Personal plans';
  $('#plans').innerHTML = Object.entries(plans).map(([k, p]) => `<button class="plan ${k === cur ? 'on' : ''}" data-plan="${k}">${k === cur ? '<span class="cur">Current plan</span>' : ''}<div class="top"><b>${p.name}</b><span>${p.price ? '$' + p.price + '/mo' : 'Free'}</span></div><ul>${p.perks.map(x => `<li>${x}</li>`).join('')}</ul></button>`).join('');
  $$('[data-plan]').forEach(b => b.onclick = () => { if (biz) state.bplan = b.dataset.plan; else state.pplan = b.dataset.plan; renderPlans(); renderAll(); toast(`You're on ${plans[b.dataset.plan].name}${plans[b.dataset.plan].price ? ' — 30-day free trial started' : ''}`); });
}

/* ---------------- shared ---------------- */
function succeed(big, p) { closeSheets(); $('#succ-big').textContent = big; $('#succ-p').textContent = p; $('#success').classList.add('show'); confetti(); renderAll(); }
$('#succ-done').onclick = () => { $('#success').classList.remove('show'); };
function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('show'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), 2000); }
function confetti() {
  const cv = $('#confetti'); cv.width = dev.clientWidth; cv.height = dev.clientHeight; const ctx = cv.getContext('2d');
  const cols = ['#FFC93C', '#FFFFFF', '#2FD69A', '#FF3D7F', '#1B1035'];
  const ps = Array.from({ length: 110 }, () => ({ x: cv.width / 2, y: cv.height * .42, vx: (Math.random() - .5) * 14, vy: -Math.random() * 14 - 4, s: Math.random() * 8 + 4, c: cols[Math.random() * cols.length | 0], r: Math.random() * 6, vr: (Math.random() - .5) * .3, round: Math.random() > .5 }));
  let f = 0; (function loop() { ctx.clearRect(0, 0, cv.width, cv.height); ps.forEach(p => { p.vy += .45; p.x += p.vx; p.y += p.vy; p.vx *= .99; p.r += p.vr; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.fillStyle = p.c; if (p.round) { ctx.beginPath(); ctx.arc(0, 0, p.s / 2, 0, 7); ctx.fill(); } else ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); ctx.restore(); }); if (++f < 110) requestAnimationFrame(loop); else ctx.clearRect(0, 0, cv.width, cv.height); })();
}
$$('.switch').forEach(s => s.onclick = () => { s.classList.toggle('on'); toast(s.classList.contains('on') ? 'Turned on' : 'Turned off'); });
function qr(svg, seed) { let h = '', x = 7; for (let i = 0; i < 21; i++) for (let j = 0; j < 21; j++) { x = (x * 1103515245 + 12345 + seed.charCodeAt((i * 21 + j) % seed.length)) & 0x7fffffff; const inF = (a, b) => i >= a && i < a + 7 && j >= b && j < b + 7; if (inF(0, 0) || inF(0, 14) || inF(14, 0)) { const ri = i < 7 ? i : i - 14, rj = j < 7 ? j : j - 14; if (ri === 0 || ri === 6 || rj === 0 || rj === 6 || (ri >= 2 && ri <= 4 && rj >= 2 && rj <= 4)) h += `<rect x="${j}" y="${i}" width="1" height="1" rx=".2" fill="#1B1035"/>`; continue; } if ((x >> 8) % 3 === 0) h += `<rect x="${j}" y="${i}" width="1" height="1" rx=".3" fill="${(i + j) % 7 === 0 ? '#FF3D7F' : '#1B1035'}"/>`; } svg.innerHTML = h; }
$$('[data-qr]').forEach(s => qr(s, s.dataset.qr));
(function () { const d = new Date(); $('#clock').textContent = (d.getHours() % 12 || 12) + ':' + String(d.getMinutes()).padStart(2, '0'); })();
function renderAll() { renderHome(); renderInvest(); renderBiz(); }
renderAll();
if (new URLSearchParams(location.search).get('mode') === 'business') setMode('business');
